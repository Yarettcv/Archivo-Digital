﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace Archivo_Digital.Controlador
{
        public class datos
        {
            public SqlDataReader dr { get; set; }// Leer un conjunto de registros.
            public SqlCommand cadena_sql { set; get; }// Instruccion de sql procedimiento almacenado 
            SqlDataAdapter adapt; // Representa una conexion de base de datos y actualiza una bd.
            SqlConnection conn; //Conecta una base de datos.

            public bool Conectar()//metodo para conectar a la base de datos.
            {
                conn = new SqlConnection();
                conn.ConnectionString = "Data source = YARETT; Initial catalog= ArchivoDigital; Integrated security=true";
                try
                {
                    conn.Open();
                    return true;
                }
                catch (Exception error)
                {
                    MessageBox.Show("Error al conectarse a la base de datos:" + error.Message);
                    return false;
                }
            }
            public void desconectar()//Metodo que desconecta la base de datos.
            {
                conn.Close();
            }
            public void construye_reader(string cadena)
            {
                cadena_sql = new SqlCommand();
                cadena_sql.Connection = conn;
                cadena_sql.CommandText = cadena;

            }

        }
    }
